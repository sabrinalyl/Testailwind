/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./pizzahutpage.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

